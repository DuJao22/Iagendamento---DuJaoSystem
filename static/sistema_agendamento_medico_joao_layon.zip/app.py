import os
import logging
import uuid
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from datetime import datetime, date, time
import json

# Configure logging com formato melhorado
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
    handlers=[
        logging.StreamHandler(),  # Console
        logging.FileHandler('sistema_agendamento.log', mode='a')  # Arquivo
    ]
)

# Logger específico para o sistema
logger = logging.getLogger('SistemaAgendamento')

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-joao-layon-2025")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the PostgreSQL database
database_url = os.environ.get("DATABASE_URL")
if not database_url:
    raise ValueError("DATABASE_URL environment variable is not set")

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize the app with the extension
db.init_app(app)

with app.app_context():
    # Import models to ensure tables are created
    from models import Paciente, Especialidade, Medico, HorarioDisponivel, Agendamento, Conversa, Local, Configuracao
    db.create_all()
    
    # Import services after models are loaded
    from ai_service import chatbot_service
    
    # Criar locais iniciais se não existirem
    if Local.query.count() == 0:
        locais = [
            Local(nome="Contagem", endereco="Rua Principal, 123", cidade="Contagem", telefone="(31) 3333-4444"),
            Local(nome="Belo Horizonte", endereco="Av. Central, 456", cidade="Belo Horizonte", telefone="(31) 2222-5555")
        ]
        
        for local in locais:
            db.session.add(local)
        
        db.session.commit()
    
    # Criar dados iniciais se não existirem
    if Especialidade.query.count() == 0:
        especialidades = [
            Especialidade(nome="Clínica Geral", descricao="Consultas gerais e check-ups"),
            Especialidade(nome="Cardiologia", descricao="Especialista em coração"),
            Especialidade(nome="Dermatologia", descricao="Cuidados com a pele"),
            Especialidade(nome="Pediatria", descricao="Especialista em crianças"),
            Especialidade(nome="Ginecologia", descricao="Saúde da mulher"),
            Especialidade(nome="Ortopedia", descricao="Ossos e articulações"),
            Especialidade(nome="Psiquiatria", descricao="Saúde mental"),
            Especialidade(nome="Oftalmologia", descricao="Cuidados com os olhos")
        ]
        
        for esp in especialidades:
            db.session.add(esp)
        
        db.session.commit()
        
        # Criar médicos de exemplo
        medicos = [
            Medico(nome="Dr. João Silva", crm="12345-SP", especialidade_id=1),
            Medico(nome="Dra. Maria Santos", crm="23456-SP", especialidade_id=2),
            Medico(nome="Dr. Carlos Oliveira", crm="34567-SP", especialidade_id=3),
            Medico(nome="Dra. Ana Costa", crm="45678-SP", especialidade_id=4),
            Medico(nome="Dr. Pedro Lima", crm="56789-SP", especialidade_id=5),
            Medico(nome="Dra. Julia Fernandes", crm="67890-SP", especialidade_id=6)
        ]
        
        for medico in medicos:
            db.session.add(medico)
        
        db.session.commit()
        
        # Buscar locais criados
        local_contagem = Local.query.filter_by(nome="Contagem").first()
        local_bh = Local.query.filter_by(nome="Belo Horizonte").first()
        
        # Criar horários de exemplo com locais específicos
        # Dr. João Silva (Clínica Geral) - Contagem segunda a sexta
        medico_joao = Medico.query.filter_by(nome="Dr. João Silva").first()
        if medico_joao:
            for dia_semana in range(5):  # Segunda a sexta
                horario = HorarioDisponivel(
                    medico_id=medico_joao.id,
                    local_id=local_contagem.id,
                    dia_semana=dia_semana,
                    hora_inicio=time(8, 0),
                    hora_fim=time(17, 0),
                    duracao_consulta=30
                )
                db.session.add(horario)
        
        # Dra. Maria Santos (Cardiologia) - BH quarta e quinta, Contagem segunda e terça
        medico_maria = Medico.query.filter_by(nome="Dra. Maria Santos").first()
        if medico_maria:
            # Segunda e terça em Contagem
            for dia_semana in [0, 1]:  # Segunda, terça
                horario = HorarioDisponivel(
                    medico_id=medico_maria.id,
                    local_id=local_contagem.id,
                    dia_semana=dia_semana,
                    hora_inicio=time(8, 0),
                    hora_fim=time(12, 0),
                    duracao_consulta=30
                )
                db.session.add(horario)
            
            # Quarta e quinta em BH
            for dia_semana in [2, 3]:  # Quarta, quinta
                horario = HorarioDisponivel(
                    medico_id=medico_maria.id,
                    local_id=local_bh.id,
                    dia_semana=dia_semana,
                    hora_inicio=time(13, 0),
                    hora_fim=time(17, 0),
                    duracao_consulta=30
                )
                db.session.add(horario)
        
        # Outros médicos com horários padrão em Contagem
        outros_medicos = [medico for medico in medicos if medico.nome not in ["Dr. João Silva", "Dra. Maria Santos"]]
        for medico in outros_medicos:
            for dia_semana in range(5):  # Segunda a sexta
                horario = HorarioDisponivel(
                    medico_id=medico.id,
                    local_id=local_contagem.id,
                    dia_semana=dia_semana,
                    hora_inicio=time(8, 0),
                    hora_fim=time(18, 0),
                    duracao_consulta=30
                )
                db.session.add(horario)
        
        db.session.commit()
    
    # Criar configurações iniciais se não existirem
    if Configuracao.query.count() == 0:
        configuracoes_iniciais = [
            ('nome_clinica', 'Clínica João Layon', 'Nome da clínica exibido no sistema'),
            ('nome_assistente', 'Assistente Virtual', 'Nome do assistente de agendamentos'),
            ('telefone_clinica', '(31) 3333-4444', 'Telefone principal da clínica'),
            ('email_admin', 'joao@gmail.com', 'Email do administrador'),
            ('senha_admin', '30031936Vo', 'Senha do administrador'),
            ('horario_funcionamento', 'Segunda a Sexta, 8h às 18h', 'Horário de funcionamento da clínica')
        ]
        
        for chave, valor, descricao in configuracoes_iniciais:
            Configuracao.set_valor(chave, valor, descricao)

@app.route('/')
def index():
    """Página principal do chatbot"""
    return render_template('chat.html')

@app.route('/agendamentos')
def listar_agendamentos():
    """Lista todos os agendamentos (apenas administradores)"""
    # Esta página é apenas para administradores
    # Em uma implementação real, você adicionaria autenticação aqui
    agendamentos = Agendamento.query.order_by(Agendamento.data, Agendamento.hora).all()
    return render_template('agendamentos.html', agendamentos=agendamentos, admin=True)

@app.route('/chat', methods=['POST'])
def processar_chat():
    """Processa mensagem do chatbot"""
    try:
        dados = request.get_json()
        mensagem = dados.get('mensagem', '').strip()
        
        if not mensagem:
            return jsonify({
                'success': False,
                'message': 'Mensagem vazia.'
            })
        
        # Obter ou criar sessão de conversa
        session_id = session.get('chat_session_id')
        if not session_id:
            session_id = str(uuid.uuid4())
            session['chat_session_id'] = session_id
        
        # Buscar conversa existente
        conversa = Conversa.query.filter_by(session_id=session_id).first()
        if not conversa:
            conversa = Conversa(session_id=session_id, estado='inicio')
            db.session.add(conversa)
            db.session.commit()
        
        # Atualizar timestamp da conversa
        conversa.atualizado_em = datetime.utcnow()
        
        # Limpeza proativa de sessões abandonadas (5% das vezes)
        import random
        if random.randint(1, 20) == 1:
            try:
                from datetime import timedelta
                data_limite = datetime.utcnow() - timedelta(hours=6)
                conversas_abandonadas = Conversa.query.filter(
                    Conversa.atualizado_em < data_limite,
                    Conversa.estado.notin_(['finalizado'])
                ).limit(5).all()
                
                if conversas_abandonadas:
                    for conv in conversas_abandonadas:
                        db.session.delete(conv)
                    logger.info(f"Limpeza: {len(conversas_abandonadas)} conversas abandonadas removidas")
            except Exception as cleanup_error:
                logger.warning(f"Erro na limpeza: {cleanup_error}")
        
        # Processar mensagem com IA
        resposta = chatbot_service.processar_mensagem(mensagem, conversa)
        
        # Salvar mudanças na conversa
        db.session.commit()
        
        return jsonify(resposta)
        
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        logger.error(f"Erro crítico no processamento do chat - Sessão: {session.get('chat_session_id', 'N/A')} - Mensagem: '{mensagem}' - Erro: {e}\n{error_details}")
        return jsonify({
            'success': False,
            'message': 'Erro interno do servidor. Nossa equipe foi notificada. Tente novamente em alguns minutos.',
            'error_id': f"ERR_{int(datetime.utcnow().timestamp())}"
        })

@app.route('/especialidades')
def listar_especialidades():
    """API para listar especialidades ativas"""
    especialidades = Especialidade.query.filter_by(ativo=True).all()
    return jsonify([esp.to_dict() for esp in especialidades])

@app.route('/locais')
def listar_locais():
    """API para listar locais ativos"""
    locais = Local.query.filter_by(ativo=True).all()
    return jsonify([local.to_dict() for local in locais])

@app.route('/cancelar/<int:agendamento_id>', methods=['POST'])
def cancelar_agendamento(agendamento_id):
    """Cancela um agendamento (admin)"""
    try:
        agendamento = Agendamento.query.get_or_404(agendamento_id)
        agendamento.status = 'cancelado'
        agendamento.cancelado_em = datetime.utcnow()
        agendamento.motivo_cancelamento = 'Cancelado pela administração'
        db.session.commit()
        
        flash('Agendamento cancelado com sucesso!', 'success')
        return redirect(url_for('listar_agendamentos'))
        
    except Exception as e:
        logging.error(f"Erro ao cancelar agendamento: {e}")
        flash('Erro ao cancelar agendamento. Tente novamente.', 'error')
        return redirect(url_for('listar_agendamentos'))

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Página de login do administrador"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        senha = request.form.get('senha', '').strip()
        
        email_admin = Configuracao.get_valor('email_admin', 'joao@gmail.com')
        senha_admin = Configuracao.get_valor('senha_admin', '30031936Vo')
        
        if email == email_admin and senha == senha_admin:
            session['admin_logado'] = True
            session['admin_email'] = email
            flash('Login realizado com sucesso!', 'success')
            return redirect(url_for('admin'))
        else:
            flash('Email ou senha incorretos.', 'error')
    
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    """Logout do administrador"""
    session.pop('admin_logado', None)
    session.pop('admin_email', None)
    flash('Logout realizado com sucesso!', 'info')
    return redirect(url_for('admin_login'))

def requer_login_admin(f):
    """Decorator para proteger rotas administrativas"""
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logado'):
            flash('Acesso negado. Faça login como administrador.', 'error')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/admin')
@requer_login_admin
def admin():
    """Página administrativa"""
    especialidades = Especialidade.query.all()
    medicos = Medico.query.all()
    locais = Local.query.all()
    horarios_disponiveis = HorarioDisponivel.query.all()
    
    # Agrupar horários por médico para melhor visualização
    horarios_agrupados = {}
    for horario in horarios_disponiveis:
        medico_nome = horario.medico_rel.nome if horario.medico_rel else 'Médico não encontrado'
        medico_id = horario.medico_id
        chave = f"{medico_id}_{medico_nome}"
        if chave not in horarios_agrupados:
            horarios_agrupados[chave] = {
                'medico_nome': medico_nome,
                'medico_id': medico_id,
                'horarios': []
            }
        horarios_agrupados[chave]['horarios'].append(horario)
    
    # Estatísticas
    total_pacientes = Paciente.query.count()
    total_agendamentos = Agendamento.query.count()
    agendamentos_hoje = Agendamento.query.filter_by(
        data=date.today(),
        status='agendado'
    ).count()
    total_especialidades = Especialidade.query.filter_by(ativo=True).count()
    
    # Stats por especialidade para relatórios
    agendamentos_por_especialidade = []
    for esp in especialidades:
        total = Agendamento.query.filter_by(especialidade_id=esp.id).count()
        agendados = Agendamento.query.filter_by(especialidade_id=esp.id, status='agendado').count()
        concluidos = Agendamento.query.filter_by(especialidade_id=esp.id, status='concluido').count()
        cancelados = Agendamento.query.filter_by(especialidade_id=esp.id, status='cancelado').count()
        
        if total > 0:  # Só incluir especialidades com agendamentos
            agendamentos_por_especialidade.append({
                'especialidade': esp.nome,
                'total': total,
                'agendados': agendados,
                'concluidos': concluidos,
                'cancelados': cancelados
            })
    
    return render_template('admin.html',
                         especialidades=especialidades,
                         medicos=medicos,
                         locais=locais,
                         horarios_disponiveis=horarios_disponiveis,
                         horarios_agrupados=horarios_agrupados,
                         total_pacientes=total_pacientes,
                         total_agendamentos=total_agendamentos,
                         agendamentos_hoje=agendamentos_hoje,
                         total_especialidades=total_especialidades,
                         agendamentos_por_especialidade=agendamentos_por_especialidade)

@app.route('/admin/config')
@requer_login_admin
def admin_config():
    """Página de configurações"""
    configuracoes = {}
    chaves_config = ['nome_clinica', 'nome_assistente', 'telefone_clinica', 'email_admin', 'horario_funcionamento']
    
    for chave in chaves_config:
        configuracoes[chave] = Configuracao.get_valor(chave, '')
    
    return render_template('admin_config.html', configuracoes=configuracoes, locais=Local.query.all())

@app.route('/admin/config', methods=['POST'])
@requer_login_admin
def salvar_config():
    """Salvar configurações"""
    try:
        nome_clinica = request.form.get('nome_clinica', '').strip()
        nome_assistente = request.form.get('nome_assistente', '').strip()
        telefone_clinica = request.form.get('telefone_clinica', '').strip()
        email_admin = request.form.get('email_admin', '').strip()
        senha_admin = request.form.get('senha_admin', '').strip()
        horario_funcionamento = request.form.get('horario_funcionamento', '').strip()
        
        if nome_clinica:
            Configuracao.set_valor('nome_clinica', nome_clinica)
        if nome_assistente:
            Configuracao.set_valor('nome_assistente', nome_assistente)
        if telefone_clinica:
            Configuracao.set_valor('telefone_clinica', telefone_clinica)
        if email_admin:
            Configuracao.set_valor('email_admin', email_admin)
        if senha_admin:
            Configuracao.set_valor('senha_admin', senha_admin)
        if horario_funcionamento:
            Configuracao.set_valor('horario_funcionamento', horario_funcionamento)
        
        flash('Configurações salvas com sucesso!', 'success')
        return redirect(url_for('admin_config'))
        
    except Exception as e:
        logging.error(f"Erro ao salvar configurações: {e}")
        flash('Erro ao salvar configurações. Tente novamente.', 'error')
        return redirect(url_for('admin_config'))

@app.route('/admin/especialidades', methods=['POST'])
@requer_login_admin
def admin_especialidades():
    """Cadastrar nova especialidade"""
    try:
        nome = request.form.get('nome', '').strip()
        descricao = request.form.get('descricao', '').strip()
        
        if not nome:
            flash('Nome da especialidade é obrigatório.', 'error')
            return redirect(url_for('admin'))
        
        # Verificar se já existe
        existe = Especialidade.query.filter_by(nome=nome).first()
        if existe:
            flash('Especialidade já existe.', 'error')
            return redirect(url_for('admin'))
        
        nova_especialidade = Especialidade(
            nome=nome,
            descricao=descricao if descricao else None
        )
        
        db.session.add(nova_especialidade)
        db.session.commit()
        
        flash(f'Especialidade "{nome}" cadastrada com sucesso!', 'success')
        return redirect(url_for('admin'))
        
    except Exception as e:
        logging.error(f"Erro ao cadastrar especialidade: {e}")
        flash('Erro ao cadastrar especialidade. Tente novamente.', 'error')
        return redirect(url_for('admin'))

@app.route('/admin/medicos', methods=['POST'])
@requer_login_admin
def admin_medicos():
    """Cadastrar novo médico"""
    try:
        nome = request.form.get('nome', '').strip()
        crm = request.form.get('crm', '').strip()
        especialidade_id_str = request.form.get('especialidade_id')
        
        # Validação de campos obrigatórios
        if not nome or not crm or not especialidade_id_str:
            flash('Todos os campos obrigatórios devem ser preenchidos.', 'error')
            return redirect(url_for('admin'))
            
        # Validação e conversão segura
        try:
            especialidade_id = int(especialidade_id_str)
            if especialidade_id <= 0:
                raise ValueError("ID de especialidade deve ser positivo")
        except (ValueError, TypeError):
            flash('Especialidade inválida selecionada.', 'error')
            return redirect(url_for('admin'))
        
        # Validação de formato do CRM
        if len(crm) < 4 or not any(c.isdigit() for c in crm):
            flash('CRM deve conter pelo menos 4 caracteres e números.', 'error')
            return redirect(url_for('admin'))
        
        # Verificar se CRM já existe
        existe = Medico.query.filter_by(crm=crm).first()
        if existe:
            flash('CRM já cadastrado.', 'error')
            return redirect(url_for('admin'))
        
        try:
            novo_medico = Medico(
                nome=nome,
                crm=crm,
                especialidade_id=especialidade_id
            )
            
            db.session.add(novo_medico)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logging.error(f"Erro ao salvar médico: {e}")
            if 'UNIQUE constraint failed' in str(e):
                flash('CRM já cadastrado no sistema.', 'error')
            else:
                flash('Erro ao cadastrar médico. Tente novamente.', 'error')
            return redirect(url_for('admin'))
        
        # Criar horários padrão (Segunda a Sexta, 8h às 18h) no primeiro local disponível
        primeiro_local = Local.query.first()
        if primeiro_local:
            for dia_semana in range(5):  # Segunda a sexta
                horario = HorarioDisponivel(
                    medico_id=novo_medico.id,
                    local_id=primeiro_local.id,
                    dia_semana=dia_semana,
                    hora_inicio=time(8, 0),
                    hora_fim=time(18, 0),
                    duracao_consulta=30
                )
                db.session.add(horario)
        
        db.session.commit()
        
        flash(f'Médico "{nome}" cadastrado com sucesso!', 'success')
        return redirect(url_for('admin'))
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Erro crítico ao cadastrar médico: {e}")
        flash('Erro interno no sistema. Tente novamente.', 'error')
        return redirect(url_for('admin'))

@app.route('/admin/horarios', methods=['POST'])
@requer_login_admin
def admin_horarios():
    """Configurar horários de médico"""
    try:
        horario_id = request.form.get('horario_id')  # Para edição
        medico_id_str = request.form.get('medico_id')
        local_id_str = request.form.get('local_id')
        dia_semana_str = request.form.get('dia_semana')
        hora_inicio = request.form.get('hora_inicio')
        hora_fim = request.form.get('hora_fim')
        duracao_consulta_str = request.form.get('duracao_consulta', '30')
        
        # Validação robusta de campos obrigatórios
        if not all([medico_id_str, local_id_str, dia_semana_str, hora_inicio, hora_fim]):
            flash('Todos os campos são obrigatórios.', 'error')
            return redirect(url_for('admin'))
            
        # Validação e conversão segura de tipos
        try:
            medico_id = int(medico_id_str)
            local_id = int(local_id_str)
            dia_semana = int(dia_semana_str)
            duracao_consulta = int(duracao_consulta_str)
            
            if medico_id <= 0 or local_id <= 0 or dia_semana < 0 or dia_semana > 6:
                raise ValueError("IDs devem ser positivos e dia da semana entre 0-6")
                
        except (ValueError, TypeError) as e:
            logging.error(f"Erro de validação em admin_horarios: {e}")
            flash('Dados inválidos fornecidos. Verifique os valores.', 'error')
            return redirect(url_for('admin'))
        
        if horario_id:
            # Editar horário existente - validação segura
            try:
                horario_id_int = int(horario_id)
                if horario_id_int <= 0:
                    raise ValueError("ID do horário inválido")
                horario = HorarioDisponivel.query.get(horario_id_int)
            except (ValueError, TypeError):
                flash('ID de horário inválido.', 'error')
                return redirect(url_for('admin'))
            if horario:
                try:
                    horario.medico_id = medico_id
                    horario.local_id = local_id
                    horario.dia_semana = dia_semana
                    horario.hora_inicio = datetime.strptime(hora_inicio, '%H:%M').time()
                    horario.hora_fim = datetime.strptime(hora_fim, '%H:%M').time()
                    horario.duracao_consulta = duracao_consulta
                    db.session.commit()
                    flash('Horário atualizado com sucesso!', 'success')
                except ValueError as e:
                    db.session.rollback()
                    logging.error(f"Erro ao atualizar horário: {e}")
                    flash('Formato de hora inválido. Use HH:MM', 'error')
                    return redirect(url_for('admin'))
            else:
                flash('Horário não encontrado.', 'error')
                return redirect(url_for('admin'))
        else:
            # Verificar se já existe configuração para este médico/local/dia
            existe = HorarioDisponivel.query.filter_by(
                medico_id=medico_id,
                local_id=local_id,
                dia_semana=dia_semana
            ).first()
            
            if existe:
                flash('Já existe horário configurado para este médico neste dia e local.', 'warning')
                return redirect(url_for('admin'))
            
            # Criar novo com validação
            try:
                novo_horario = HorarioDisponivel(
                    medico_id=medico_id,
                    local_id=local_id,
                    dia_semana=dia_semana,
                    hora_inicio=datetime.strptime(hora_inicio, '%H:%M').time(),
                    hora_fim=datetime.strptime(hora_fim, '%H:%M').time(),
                    duracao_consulta=duracao_consulta
                )
                db.session.add(novo_horario)
                db.session.commit()
                flash('Horário criado com sucesso!', 'success')
            except ValueError as e:
                db.session.rollback()
                logging.error(f"Erro ao criar horário: {e}")
                flash('Formato de hora inválido. Use HH:MM', 'error')
                return redirect(url_for('admin'))
        return redirect(url_for('admin'))
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Erro crítico ao configurar horário: {e}")
        flash('Erro interno ao configurar horário. Tente novamente.', 'error')
        return redirect(url_for('admin'))

@app.route('/admin/locais', methods=['POST'])
@requer_login_admin
def admin_locais():
    """Cadastrar novo local de atendimento"""
    try:
        nome = request.form.get('nome', '').strip()
        endereco = request.form.get('endereco', '').strip()
        cidade = request.form.get('cidade', '').strip()
        telefone = request.form.get('telefone', '').strip()
        
        if not nome or not cidade:
            flash('Nome e cidade são obrigatórios.', 'error')
            return redirect(url_for('admin'))
        
        # Verificar se já existe
        existe = Local.query.filter_by(nome=nome).first()
        if existe:
            flash('Local já existe.', 'error')
            return redirect(url_for('admin'))
        
        novo_local = Local(
            nome=nome,
            endereco=endereco if endereco else None,
            cidade=cidade,
            telefone=telefone if telefone else None
        )
        
        db.session.add(novo_local)
        db.session.commit()
        
        flash(f'Local "{nome}" cadastrado com sucesso!', 'success')
        return redirect(url_for('admin'))
        
    except Exception as e:
        logging.error(f"Erro ao cadastrar local: {e}")
        flash('Erro ao cadastrar local. Tente novamente.', 'error')
        return redirect(url_for('admin'))

@app.route('/admin/especialidade/<int:especialidade_id>/delete', methods=['POST'])
@requer_login_admin
def deletar_especialidade(especialidade_id):
    """Deletar uma especialidade"""
    try:
        especialidade = Especialidade.query.get_or_404(especialidade_id)
        
        # Verificar se há médicos usando esta especialidade
        medicos_usando = Medico.query.filter_by(especialidade_id=especialidade_id).count()
        if medicos_usando > 0:
            flash(f'Não é possível deletar "{especialidade.nome}" pois existem {medicos_usando} médico(s) cadastrado(s) nesta especialidade.', 'error')
            return redirect(url_for('admin'))
        
        # Verificar se há agendamentos usando esta especialidade
        agendamentos_usando = Agendamento.query.filter_by(especialidade_id=especialidade_id).count()
        if agendamentos_usando > 0:
            flash(f'Não é possível deletar "{especialidade.nome}" pois existem {agendamentos_usando} agendamento(s) registrado(s) nesta especialidade.', 'error')
            return redirect(url_for('admin'))
        
        nome_especialidade = especialidade.nome
        db.session.delete(especialidade)
        db.session.commit()
        
        flash(f'Especialidade "{nome_especialidade}" deletada com sucesso!', 'success')
        return redirect(url_for('admin'))
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Erro ao deletar especialidade: {e}")
        flash('Erro ao deletar especialidade. Tente novamente.', 'error')
        return redirect(url_for('admin'))

@app.route('/admin/medico/<int:medico_id>/delete', methods=['POST'])
@requer_login_admin
def deletar_medico(medico_id):
    """Deletar um médico"""
    try:
        medico = Medico.query.get_or_404(medico_id)
        
        # Verificar se há agendamentos futuros para este médico
        from datetime import date
        agendamentos_futuros = Agendamento.query.filter_by(
            medico_id=medico_id,
            status='agendado'
        ).filter(Agendamento.data >= date.today()).count()
        
        if agendamentos_futuros > 0:
            flash(f'Não é possível deletar "{medico.nome}" pois existem {agendamentos_futuros} agendamento(s) futuro(s) para este médico.', 'error')
            return redirect(url_for('admin'))
        
        nome_medico = medico.nome
        
        # Deletar horários disponíveis do médico
        HorarioDisponivel.query.filter_by(medico_id=medico_id).delete()
        
        # Deletar o médico
        db.session.delete(medico)
        db.session.commit()
        
        flash(f'Médico "{nome_medico}" deletado com sucesso!', 'success')
        return redirect(url_for('admin'))
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Erro ao deletar médico: {e}")
        flash('Erro ao deletar médico. Tente novamente.', 'error')
        return redirect(url_for('admin'))

@app.route('/admin/local/<int:local_id>/delete', methods=['POST'])
@requer_login_admin
def deletar_local(local_id):
    """Deletar um local"""
    try:
        local = Local.query.get_or_404(local_id)
        
        # Verificar se há agendamentos futuros para este local
        from datetime import date
        agendamentos_futuros = Agendamento.query.filter_by(
            local_id=local_id,
            status='agendado'
        ).filter(Agendamento.data >= date.today()).count()
        
        if agendamentos_futuros > 0:
            flash(f'Não é possível deletar "{local.nome}" pois existem {agendamentos_futuros} agendamento(s) futuro(s) para este local.', 'error')
            return redirect(url_for('admin'))
        
        # Verificar se há horários disponíveis para este local
        horarios_usando = HorarioDisponivel.query.filter_by(local_id=local_id).count()
        if horarios_usando > 0:
            flash(f'Não é possível deletar "{local.nome}" pois existem {horarios_usando} horário(s) configurado(s) neste local.', 'error')
            return redirect(url_for('admin'))
        
        nome_local = local.nome
        db.session.delete(local)
        db.session.commit()
        
        flash(f'Local "{nome_local}" deletado com sucesso!', 'success')
        return redirect(url_for('admin'))
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Erro ao deletar local: {e}")
        flash('Erro ao deletar local. Tente novamente.', 'error')
        return redirect(url_for('admin'))

@app.route('/admin/horario/<int:horario_id>/delete', methods=['POST'])
@requer_login_admin
def deletar_horario(horario_id):
    """Deletar um horário"""
    try:
        horario = HorarioDisponivel.query.get_or_404(horario_id)
        
        medico_nome = horario.medico_rel.nome if horario.medico_rel else 'N/A'
        dia_nome = horario.get_dia_semana_nome()
        
        db.session.delete(horario)
        db.session.commit()
        
        flash(f'Horário de {medico_nome} ({dia_nome}) deletado com sucesso!', 'success')
        return redirect(url_for('admin'))
        
    except Exception as e:
        db.session.rollback()
        logging.error(f"Erro ao deletar horário: {e}")
        flash('Erro ao deletar horário. Tente novamente.', 'error')
        return redirect(url_for('admin'))

@app.route('/api/status')
def api_status():
    """Endpoint de status da API"""
    total_agendamentos = Agendamento.query.count()
    agendamentos_hoje = Agendamento.query.filter_by(
        data=date.today(),
        status='agendado'
    ).count()
    total_pacientes = Paciente.query.count()
    
    return jsonify({
        'status': 'ativo',
        'desenvolvedor': 'João Layon',
        'versao': '2.0.0 - Chatbot Avançado',
        'total_agendamentos': total_agendamentos,
        'agendamentos_hoje': agendamentos_hoje,
        'total_pacientes': total_pacientes,
        'especialidades': Especialidade.query.filter_by(ativo=True).count(),
        'preco_mensal': 'R$ 19,90'
    })

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)